SMODS.Rarity {
    key = "not_done",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('ffffff'),
    loc_txt = {
        name = "Not Done"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "ejt_common",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.65,
    badge_colour = HEX('000000'),
    loc_txt = {
        name = "EJT - Common"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "ejt_uncommon",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.25,
    badge_colour = HEX('000000'),
    loc_txt = {
        name = "EJT - Uncommon"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "ejt_rare",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.09,
    badge_colour = HEX('000000'),
    loc_txt = {
        name = "EJT - Rare"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "ejt_legendary",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.008,
    badge_colour = HEX('000000'),
    loc_txt = {
        name = "EJT - Legendary"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "ejt_legendary2",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.002,
    badge_colour = HEX('000000'),
    loc_txt = {
        name = "EJT - Legendary+"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}