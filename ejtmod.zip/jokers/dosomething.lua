SMODS.Joker{ --Do Something
    key = "dosomething",
    config = {
        extra = {
            chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'Do Something',
        ['text'] = {
            [1] = 'Gains {C:blue}+5{} Chips per hand played {C:inactive}(Currently{} {C:blue}+#1# {}{C:inactive}chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.chips}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                card.ability.extra.chips = (card.ability.extra.chips) + 10
                return {
                    chips = card.ability.extra.chips
                }
        end
    end
}