
SMODS.Joker{ --Missing
    key = "missing",
    config = {
        extra = {
            varran = 0,
            discardsusedthisround = 0,
            xmult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Missing',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult if exactly #1# {C:attention}discards{} used. {C:inactive}(Changes each round){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = "ejtmod_ejt_rare",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.varran, (G.GAME.current_round.discards_used or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(card.ability.extra.varran) == to_big(G.GAME.current_round.discards_used) then
                return {
                    Xmult = 3
                }
            end
        end
        if context.setting_blind  then
            return {
                func = function()
                    card.ability.extra.varran = pseudorandom('RANGE:0|3', 0, 3)
                    return true
                end
            }
        end
    end
}