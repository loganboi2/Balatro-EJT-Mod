
SMODS.Joker{ --Malicious
    key = "malicious",
    config = {
        extra = {
            multvar = 0,
            consumablesheld = 0
        }
    },
    loc_txt = {
        ['name'] = 'Malicious',
        ['text'] = {
            [1] = 'When {C:attention}Blind{} selected, {C:hearts}destroy{}',
            [2] = 'a consumable and then gain {C:red}+4{} Mult',
            [3] = '{C:inactive}(Currently{} {C:red}+#1# {}{C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar, (#(G.consumeables and G.consumeables.cards or {}) or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if to_big(#(G.consumeables and G.consumeables.cards or {})) > to_big(0) then
                return {
                    func = function()
                        card.ability.extra.multvar = (card.ability.extra.multvar) + 4
                        return true
                    end,
                    extra = {
                        func = function()
                            local target_cards = {}
                            for i, consumable in ipairs(G.consumeables.cards) do
                                table.insert(target_cards, consumable)
                            end
                            if #target_cards > 0 then
                                local card_to_destroy = pseudorandom_element(target_cards, pseudoseed('destroy_consumable'))
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        card_to_destroy:start_dissolve()
                                        return true
                                    end
                                }))
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed Consumable!", colour = G.C.RED})
                            end
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.multvar
            }
        end
    end
}