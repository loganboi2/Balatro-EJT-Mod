SMODS.Joker{ --Roll
    key = "roll",
    config = {
        extra = {
            dollars = 3
        }
    },
    loc_txt = {
        ['name'] = 'Roll',
        ['text'] = {
            [1] = 'Earn {C:money}$3 {}every time you reroll.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    calculate = function(self, card, context)
        if context.reroll_shop  then
                return {
                    dollars = card.ability.extra.dollars
                }
        end
    end
}