SMODS.Joker{ --Spontaneous
    key = "spontaneous",
    config = {
        extra = {
            discardsusedthisround = 0,
            mult = 15
        }
    },
    loc_txt = {
        ['name'] = 'Spontaneous',
        ['text'] = {
            [1] = '{C:red}+15{} Mult if no discards used'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.current_round.discards_used == 0 then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}