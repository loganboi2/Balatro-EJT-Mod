
SMODS.Joker{ --Are You Done Yet?
    key = "areyoudoneyet",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Are You Done Yet?',
        ['text'] = {
            [1] = 'Create two {C:tarot}tarot{} cards',
            [2] = 'if you have {C:attention}1 hand remaining{}',
            [3] = '{C:inactive}(must have room){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "ejtmod_ejt_rare",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.hand_drawn  then
            if to_big(G.GAME.current_round.hands_left) == to_big(1) then
                return {
                    func = function()
                        
                        for i = 1, math.min(2, G.consumeables.config.card_limit - #G.consumeables.cards) do
                            G.E_MANAGER:add_event(Event({
                                trigger = 'after',
                                delay = 0.4,
                                func = function()
                                    play_sound('timpani')
                                    SMODS.add_card({ set = 'Tarot', })                            
                                    card:juice_up(0.3, 0.5)
                                    return true
                                end
                            }))
                        end
                        delay(0.6)
                        
                        if created_consumable then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                        end
                        return true
                    end
                }
            end
        end
    end
}