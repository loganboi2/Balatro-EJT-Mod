SMODS.Joker{ --Gravel
    key = "gravel",
    config = {
        extra = {
            chipvar = 125,
            cardsinhand = 0
        }
    },
    loc_txt = {
        ['name'] = 'Gravel',
        ['text'] = {
            [1] = '{C:blue}+125{} Chips.',
            [2] = '{C:red}-10{} Chips per card played in hand'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.chipvar = math.max(0, (card.ability.extra.chipvar) - (#(G.hand and G.hand.cards or {})) * 10)
                    return true
                end
                }
        end
        if context.hand_drawn  then
                return {
                    func = function()
                    card.ability.extra.chipvar = 125
                    return true
                end
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chipvar
                }
        end
    end
}