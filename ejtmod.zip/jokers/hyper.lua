SMODS.Joker{ --HYPER
    key = "hyper",
    config = {
        extra = {
            chips = 20,
            chips2 = 20
        }
    },
    loc_txt = {
        ['name'] = 'HYPER',
        ['text'] = {
            [1] = '{C:blue}+20{} Chips for every {C:attention}#1# {}and {C:attention}#2# {} in hand.',
            [2] = 'Suits change each round.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {localize((G.GAME.current_round.suitvar_card or {}).suit or 'Spades', 'suits_singular'), localize((G.GAME.current_round.suitvar2_card or {}).suit or 'Spades', 'suits_singular')}, colours = {G.C.SUITS[(G.GAME.current_round.suitvar_card or {}).suit or 'Spades'], G.C.SUITS[(G.GAME.current_round.suitvar2_card or {}).suit or 'Spades']}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.suitvar_card = { suit = 'Spades' }
        G.GAME.current_round.suitvar2_card = { suit = 'Spades' }
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit(G.GAME.current_round.suitvar_card.suit) then
                return {
                    chips = card.ability.extra.chips
                }
            elseif context.other_card:is_suit(G.GAME.current_round.suitvar2_card.suit) then
                return {
                    chips = card.ability.extra.chips2
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                if G.playing_cards then
                    local valid_suitvar_cards = {}
                    for _, v in ipairs(G.playing_cards) do
                        if not SMODS.has_no_suit(v) then
                            valid_suitvar_cards[#valid_suitvar_cards + 1] = v
                        end
                    end
                    if valid_suitvar_cards[1] then
                        local suitvar_card = pseudorandom_element(valid_suitvar_cards, pseudoseed('suitvar' .. G.GAME.round_resets.ante))
                        G.GAME.current_round.suitvar_card.suit = suitvar_card.base.suit
                    end
                end
                if G.playing_cards then
                    local valid_suitvar2_cards = {}
                    for _, v in ipairs(G.playing_cards) do
                        if not SMODS.has_no_suit(v) then
                            valid_suitvar2_cards[#valid_suitvar2_cards + 1] = v
                        end
                    end
                    if valid_suitvar2_cards[1] then
                        local suitvar2_card = pseudorandom_element(valid_suitvar2_cards, pseudoseed('suitvar2' .. G.GAME.round_resets.ante))
                        G.GAME.current_round.suitvar2_card.suit = suitvar2_card.base.suit
                    end
                end
        end
    end
}