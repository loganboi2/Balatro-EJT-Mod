
SMODS.Joker{ --Instant Win
    key = "instantwin",
    config = {
        extra = {
            multvar = 0,
            currentante = 0
        }
    },
    loc_txt = {
        ['name'] = 'Instant Win',
        ['text'] = {
            [1] = 'Gives {C:red}+3 {}Mult for each Ante'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar, ((G.GAME.round_resets.ante or 0)) * 3}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.multvar
            }
        end
        if context.setting_blind  then
            return {
                func = function()
                    card.ability.extra.multvar = (G.GAME.round_resets.ante) * 3
                    return true
                end
            }
        end
    end
}