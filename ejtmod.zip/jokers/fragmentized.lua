SMODS.Joker{ --Fragmentized
    key = "fragmentized",
    config = {
        extra = {
            xmult = 0,
            ante_value = 1
        }
    },
    loc_txt = {
        ['name'] = 'Fragmentized',
        ['text'] = {
            [1] = '{C:attention}-1{} Ante each {C:blue}hand{}.',
            [2] = 'Gains {X:red,C:white}X2{} Mult',
            [3] = '{C:inactive}( Currently{} {X:red,C:white} X#1# {} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 50,
    rarity = "ejtmod_ejt_legendary2",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                local mod = -card.ability.extra.ante_value
		ease_ante(mod)
		G.E_MANAGER:add_event(Event({
			func = function()
				G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
				return true
			end,
		}))
                card.ability.extra.xmult = (card.ability.extra.xmult) + 2
                return {
                    message = "Ante -" .. card.ability.extra.ante_value,
                    extra = {
                        Xmult = card.ability.extra.xmult
                        }
                }
        end
    end
}