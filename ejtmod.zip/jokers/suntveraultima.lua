SMODS.Joker{ --Sunt Vera Ultima
    key = "suntveraultima",
    config = {
        extra = {
            odds = 10,
            joker_slots = 1
        }
    },
    loc_txt = {
        ['name'] = 'Sunt Vera Ultima',
        ['text'] = {
            [1] = '{C:green}1 in 10{} chance when a joker is bought',
            [2] = 'to gain {C:blue}+1{} {C:attention}Joker Slot{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = "ejtmod_ejt_legendary",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    calculate = function(self, card, context)
        if context.buying_card  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_a686f6eb', 1, card.ability.extra.odds, 'j_ejtmod_suntveraultima', false) then
              SMODS.calculate_effect({func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.joker_slots).." Joker Slot", colour = G.C.DARK_EDITION})
                G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.joker_slots
                return true
            end}, card)
          end
            end
        end
    end
}