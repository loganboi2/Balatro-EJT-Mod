SMODS.Joker{ --Joyful
    key = "joyful",
    config = {
        extra = {
            multx = 1
        }
    },
    loc_txt = {
        ['name'] = 'Joyful',
        ['text'] = {
            [1] = 'If {C:attention}blind{} is skipped, this joker',
            [2] = 'gives {X:red,C:white}X3{} Mult the next round.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    calculate = function(self, card, context)
        if context.skip_blind  then
                return {
                    func = function()
                    card.ability.extra.multx = 3
                    return true
                end
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.multx
                }
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.multx = 1
                    return true
                end
                }
        end
    end
}