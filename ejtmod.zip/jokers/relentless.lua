SMODS.Joker{ --Relentless
    key = "relentless",
    config = {
        extra = {
            chips = 15,
            mult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Relentless',
        ['text'] = {
            [1] = '{C:attention}Numbered {}cards give {C:blue}+15 chips{}',
            [2] = '{C:attention}Face{} cards give {C:red}+2{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if ((context.other_card:get_id() == 2 or context.other_card:get_id() == 4 or context.other_card:get_id() == 6 or context.other_card:get_id() == 8 or context.other_card:get_id() == 10) or (context.other_card:get_id() == 14 or context.other_card:get_id() == 3 or context.other_card:get_id() == 5 or context.other_card:get_id() == 7 or context.other_card:get_id() == 9)) then
                return {
                    chips = card.ability.extra.chips
                }
            elseif context.other_card:is_face() then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}