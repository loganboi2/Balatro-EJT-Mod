SMODS.Joker{ --Millisecondless
    key = "millisecondless",
    config = {
        extra = {
            multvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Millisecondless',
        ['text'] = {
            [1] = 'Each scored card gives {C:red}+1{} Mult',
            [2] = 'per {C:attention}previous numbered card{}',
            [3] = 'scored in this hand'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.multvar = 0
                    return true
                end
                }
        end
        if context.individual and context.cardarea == G.play  then
            if ((context.other_card:get_id() == 2 or context.other_card:get_id() == 4 or context.other_card:get_id() == 6 or context.other_card:get_id() == 8 or context.other_card:get_id() == 10) or (context.other_card:get_id() == 14 or context.other_card:get_id() == 3 or context.other_card:get_id() == 5 or context.other_card:get_id() == 7 or context.other_card:get_id() == 9)) then
                card.ability.extra.multvar = (card.ability.extra.multvar) + 1
                return {
                    mult = card.ability.extra.multvar
                }
            end
        end
    end
}