
SMODS.Joker{ --Reversed
    key = "reversed",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Reversed',
        ['text'] = {
            [1] = 'Swap {C:blue}Chips{} and {C:red}Mult{} before hand is played.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },
    soul_pos = {
        x = 4,
        y = 1
    },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[1] then
                return {
                    swap = true
                }
            end
        end
    end
}