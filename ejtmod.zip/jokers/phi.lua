
SMODS.Joker{ --Phi
    key = "phi",
    config = {
        extra = {
            multvar = 0,
            remaining = 1,
            F1 = 1,
            F2 = 1,
            F3 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Phi',
        ['text'] = {
            [1] = 'Gains {C:red}+5{} Mult after playing {C:attention}#2# {}{C:blue}hands{}',
            [2] = 'Requirement then {C:attention}increases{} to {C:attention}F(n){}',
            [3] = '{C:inactive}(Currently{} {C:red}+#1# {}{C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = "ejtmod_ejt_uncommon",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar, card.ability.extra.remaining, card.ability.extra.F1, card.ability.extra.F2, card.ability.extra.F3}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            card.ability.extra.remaining = math.max(0, (card.ability.extra.remaining) - 1)
            return {
                mult = card.ability.extra.multvar
            }
        end
        if context.after and context.cardarea == G.jokers  then
            if to_big(card.ability.extra.remaining) == to_big(0) then
                local F1_value = card.ability.extra.F1
                local F2_value = card.ability.extra.F2
                return {
                    func = function()
                        card.ability.extra.multvar = (card.ability.extra.multvar) + 5
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.F3 = card.ability.extra.F1
                            return true
                        end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                                card.ability.extra.F1 = (card.ability.extra.F1) + card.ability.extra.F2
                                return true
                            end,
                            colour = G.C.GREEN,
                            extra = {
                                func = function()
                                    card.ability.extra.F2 = card.ability.extra.F3
                                    return true
                                end,
                                colour = G.C.BLUE,
                                extra = {
                                    func = function()
                                        card.ability.extra.remaining = card.ability.extra.F1
                                        return true
                                    end,
                                    colour = G.C.BLUE
                                }
                            }
                        }
                    }
                }
            end
        end
    end
}