SMODS.Joker{ --Insistent
    key = "insistent",
    config = {
        extra = {
            multvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Insistent',
        ['text'] = {
            [1] = '{C:red}+4{} Mult when {C:attention}exiting shop.{}',
            [2] = '{C:red}-1{} Mult when something is {C:attention}bought.{}',
            [3] = '{C:inactive}(Currently{} {C:red}+#1# {}{C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_uncommon",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.multvar}}
    end,

    calculate = function(self, card, context)
        if context.ending_shop  then
                return {
                    func = function()
                    card.ability.extra.multvar = (card.ability.extra.multvar) + 4
                    return true
                end
                }
        end
        if context.buying_card  then
                return {
                    func = function()
                    card.ability.extra.multvar = math.max(0, (card.ability.extra.multvar) - 1)
                    return true
                end
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.multvar
                }
        end
    end
}