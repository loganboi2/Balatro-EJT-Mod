
SMODS.Joker{ --Aleph-Virus
    key = "alephvirus",
    config = {
        extra = {
            xmult0_min = NaN,
            xmult0_max = 3.99
        }
    },
    loc_txt = {
        ['name'] = 'Aleph-Virus',
        ['text'] = {
            [1] = '{X:red,C:white}X1{} - {X:red,C:white}X4{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "ejtmod_ejt_rare",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = pseudorandom('RANGE:1.01|3.99', 1.01, 3.99)
            }
        end
    end
}