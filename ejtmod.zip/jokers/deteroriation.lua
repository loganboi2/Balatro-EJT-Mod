
SMODS.Joker{ --Deteroriation
    key = "deteroriation",
    config = {
        extra = {
            rvar = 2
        }
    },
    loc_txt = {
        ['name'] = 'Deteroriation',
        ['text'] = {
            [1] = 'Retriggers played cards {C:attention}#1# {} times.',
            [2] = '{C:hearts}Decreases{} by 1 {C:attention}each round{}',
            [3] = '{C:green}Increases{} by 1 if a {C:attention}card is sold{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = "ejtmod_ejt_legendary",
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.rvar}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if to_big((card.ability.extra.rvar or 0)) <= to_big(0) then
                return {
                    func = function()
                        local target_joker = card
                        
                        if target_joker then
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end
                }
            else
                return {
                    func = function()
                        card.ability.extra.rvar = math.max(0, (card.ability.extra.rvar) - 1)
                        return true
                    end
                }
            end
        end
        if context.selling_card  then
            return {
                func = function()
                    card.ability.extra.rvar = (card.ability.extra.rvar) + 1
                    return true
                end
            }
        end
        if context.repetition and context.cardarea == G.play  then
            return {
                repetitions = card.ability.extra.rvar,
                message = localize('k_again_ex')
            }
        end
    end
}