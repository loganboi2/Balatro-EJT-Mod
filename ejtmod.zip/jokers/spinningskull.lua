SMODS.Joker{ --Spinning Skull
    key = "spinningskull",
    config = {
        extra = {
            xmultvar = 1,
            repetitions = 3
        }
    },
    loc_txt = {
        ['name'] = 'Spinning Skull',
        ['text'] = {
            [1] = 'Retrigger 6s thrice. Each 6 gives {X:red,C:white}X#1# {} mult.',
            [2] = 'Increase by {C:hearts}X0.1{} for each scored card that isn\'t a 6.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 50,
    rarity = "ejtmod_ejt_legendary2",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmultvar}}
    end,

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card:get_id() == 6 then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = "Retrigger!"
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 6 then
                return {
                    Xmult = card.ability.extra.xmultvar
                }
            elseif not (context.other_card:get_id() == 6) then
                card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + 0.1
                return {
                    message = "Increase!"
                }
            end
        end
    end
}