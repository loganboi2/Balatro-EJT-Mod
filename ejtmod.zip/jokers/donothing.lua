SMODS.Joker{ --Do Nothing
    key = "donothing",
    config = {
        extra = {
            mult = 12,
            start_dissolve = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Do Nothing',
        ['text'] = {
            [1] = '{C:red}+#1# {}Mult. {C:hearts}-2{} Mult per hand played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.mult
                }
        end
        if context.after and context.cardarea == G.jokers  then
            if (card.ability.extra.mult or 0) < 1 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end
                }
            else
                return {
                    func = function()
                    card.ability.extra.mult = math.max(0, (card.ability.extra.mult) - 2)
                    return true
                end
                }
            end
        end
    end
}