SMODS.Joker{ --MegaDeath
    key = "megadeath",
    config = {
        extra = {
            chipvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'MegaDeath',
        ['text'] = {
            [1] = 'Gains {C:blue}+6{} Chips every time',
            [2] = 'a face card is played {C:inactive}(Currently {}{C:blue}+#1#{}{C:inactive} chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "ejtmod_ejt_uncommon",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.chipvar}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                card.ability.extra.chipvar = (card.ability.extra.chipvar) + 6
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chipvar
                }
        end
    end
}