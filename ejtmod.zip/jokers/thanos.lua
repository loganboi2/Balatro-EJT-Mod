
SMODS.Joker{ --Thanos
    key = "thanos",
    config = {
        extra = {
            xmult0 = 0.5,
            dollars0 = 12
        }
    },
    loc_txt = {
        ['name'] = 'Thanos',
        ['text'] = {
            [1] = '{X:red,C:white}X0.5{} Mult',
            [2] = 'Earn {C:money}$12{} at end of round.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "ejtmod_ejt_common",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
        end
        if context.other_joker  then
            if (function()
                return G.jokers.cards[#G.jokers.cards] == context.other_joker
            end)() then
                return {
                    Xmult = 0.5
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 12
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(12), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end
}