
SMODS.Joker{ --Vacant
    key = "vacant",
    config = {
        extra = {
            consumablesheld = 0
        }
    },
    loc_txt = {
        ['name'] = 'Vacant',
        ['text'] = {
            [1] = 'When blind selected, create a {C:planet}planet{} card',
            [2] = 'if you have {C:attention}no consumables{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "ejtmod_ejt_uncommon",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(#(G.consumeables and G.consumeables.cards or {}) or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if to_big(#(G.consumeables and G.consumeables.cards or {})) == to_big(0) then
                return {
                    func = function()
                        
                        for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                            G.E_MANAGER:add_event(Event({
                                trigger = 'after',
                                delay = 0.4,
                                func = function()
                                    play_sound('timpani')
                                    SMODS.add_card({ set = 'Planet', })                            
                                    card:juice_up(0.3, 0.5)
                                    return true
                                end
                            }))
                        end
                        delay(0.6)
                        
                        if created_consumable then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_planet'), colour = G.C.SECONDARY_SET.Planet})
                        end
                        return true
                    end
                }
            end
        end
    end
}