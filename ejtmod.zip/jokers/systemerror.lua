SMODS.Joker{ --System Error
    key = "systemerror",
    config = {
        extra = {
            xmult = 1,
            Xmult = 3,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'System Error',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult if hand only contains',
            [2] = '{C:hearts}Hearts{} and {C:diamonds}Diamonds{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "ejtmod_ejt_uncommon",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["ejtmod_ejtmod_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Spades") or context.other_card:is_suit("Clubs") then
                card.ability.extra.xmult = 0
            end
        end
        if context.before and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.var1 = (card.ability.extra.var1) + 1
                    return true
                end
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (1 == card.ability.extra.xmult and (function()
    local suitCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:is_suit("Hearts") then
            suitCount = suitCount + 1
        end
    end
    
    return suitCount >= 1
end)() and (function()
    local suitCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:is_suit("Diamonds") then
            suitCount = suitCount + 1
        end
    end
    
    return suitCount >= 1
end)()) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}