SMODS.Sound{
    key="microwave",
    path="microwave.ogg",
    pitch=1,
    volume=0.2,
    replace=""
}